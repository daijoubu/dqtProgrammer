Serial Number,{0|0|0}
Delta-Q Model,{1|0|0}
Factory SW Identifier,{165|0|0}
Charger Software,v{25|1|0}.{25|1|1}.{25|2|4}
Active Charging Profile,{27|2|0}.{27|1|2}.{27|1|3}
Battery Pack Capacity Ah,{172|3|0}
Finished Goods Assembly Number,{71|0|0}

Total AmpHours Returned,{11|4|0}
Total Completed Charges,{15|5|0} 
Total Maintenance Charges,{17|5|0} 
Total Equalization Charges,{16|5|0} 
Total AC Interrupted Charges,{20|5|0} 
Total DC Interrupted Charges,{19|5|0} 
Total Charge Duration Seconds,{13|5|0} 
Total Equivalent Full Power Hours,{14|6|0} 

Available Charging Profile(s):
Slot 0,{67|2|0}.{67|1|2}.{67|1|3}
Slot 1,{67|2|6}.{67|1|8}.{67|1|9}
Slot 2,{67|2|12}.{67|1|14}.{67|1|15}
Slot 3,{67|2|18}.{67|1|20}.{67|1|21}
Slot 4,{67|2|24}.{67|1|26}.{67|1|27}
Slot 5,{67|2|30}.{67|1|32}.{67|1|33}
Slot 6,{67|2|36}.{67|1|38}.{67|1|39}
Slot 7,{67|2|42}.{67|1|44}.{67|1|45}
Slot 8,{67|2|48}.{67|1|50}.{67|1|51}
Slot 9,{67|2|54}.{67|1|56}.{67|1|57}
Slot 10,{67|2|60}.{67|1|62}.{67|1|63}
Slot 11,{67|2|66}.{67|1|68}.{67|1|69}
Slot 12,{67|2|72}.{67|1|74}.{67|1|75}
Slot 13,{67|2|78}.{67|1|80}.{67|1|81}
Slot 14,{67|2|84}.{67|1|86}.{67|1|87}
Slot 15,{67|2|90}.{67|1|92}.{67|1|93}
Slot 16,{67|2|96}.{67|1|98}.{67|1|99}
Slot 17,{67|2|102}.{67|1|104}.{67|1|105}
Slot 18,{67|2|108}.{67|1|110}.{67|1|111}
Slot 19,{67|2|114}.{67|1|116}.{67|1|117}
Slot 20,{67|2|120}.{67|1|122}.{67|1|123}
Slot 21,{67|2|126}.{67|1|128}.{67|1|129}
Slot 22,{67|2|132}.{67|1|134}.{67|1|135}
Slot 23,{67|2|138}.{67|1|140}.{67|1|141}
Slot 24,{67|2|144}.{67|1|146}.{67|1|147}
